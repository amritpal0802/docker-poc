from django.db import models

# Create your models here.



class TestModel(models.Model):
    amount = models.DecimalField(max_digits=8, decimal_places=3, default=0.000)
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    updated_at = models.DateTimeField(auto_now=True, null=True)
    class Meta:
        ordering = ["-id"]


class TransactionLog(models.Model):
    hash = models.TextField(null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-id"]