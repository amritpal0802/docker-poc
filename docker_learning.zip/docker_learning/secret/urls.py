from django.conf.urls import url
from django.urls import path
from secret.views import Home

urlpatterns = [
    path('', Home)
]