from datetime import datetime
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect
from django.contrib import auth
from django.http import HttpResponse
from django.views.generic import TemplateView
# Create your views here.


def Home(request):
    return render(request, 'index.html')
